package com.org.springbootapachkafkarealworldproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootApachKafkaRealWorldProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootApachKafkaRealWorldProjectApplication.class, args);
	}

}
