package com.org.springbootapacheKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootApacheKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
