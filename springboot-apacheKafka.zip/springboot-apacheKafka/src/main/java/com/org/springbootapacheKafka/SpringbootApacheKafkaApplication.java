package com.org.springbootapacheKafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootApacheKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootApacheKafkaApplication.class, args);
	}

}
