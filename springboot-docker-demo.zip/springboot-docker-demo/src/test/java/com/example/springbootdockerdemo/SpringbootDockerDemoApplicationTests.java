package com.example.springbootdockerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDockerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
