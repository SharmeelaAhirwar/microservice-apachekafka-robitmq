package com.org.springbootrestfullwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRestfullWebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRestfullWebserviceApplication.class, args);
	}

}
