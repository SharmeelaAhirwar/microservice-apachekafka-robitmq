package com.org.springbootrestfullwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRestfullWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
